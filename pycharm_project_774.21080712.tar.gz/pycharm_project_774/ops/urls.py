from django.conf.urls import include, url
from django.contrib import admin
from rest_framework.routers import DefaultRouter
from rest_framework.documentation import include_docs_urls
from idcs.views import IdcViewset
from users.views import UserViewset
from cabinet.views import CabinetViewset
from manufacturer.views import ManufacturerViewset,ProductModelViewset
from servers.views import ServerAutoReportViewset,NetworkDeviceViewset,IPViewset,ServerViewset


route = DefaultRouter()
route.register("idcs",IdcViewset,base_name="idcs")
route.register("users",UserViewset,base_name="users")
route.register("cabinet",CabinetViewset,base_name="cabinet")
route.register("Manufacturer",ManufacturerViewset,base_name="Manufacturer")
route.register("ProductModel",ProductModelViewset,base_name="ProductModel")
route.register("ServerAutoReport",ServerAutoReportViewset,base_name="ServerAutoReport")
route.register("Servers",ServerViewset,base_name="Servers")
route.register("NetworkDevice",NetworkDeviceViewset,base_name="NetworkDevice")
route.register("IP",IPViewset,base_name="IP")


urlpatterns = [
    url(r'^', include(route.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    url(r'^docs/', include_docs_urls("51reboot运维平台接口文档"))
]

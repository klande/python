from rest_framework import serializers
from idcs.serializers import IdcSerializer
from .models import Cabinet
from idcs.models import Idc

class CabinetSerializer(serializers.Serializer):
    idc = serializers.PrimaryKeyRelatedField(many=False,queryset=Idc.objects.all())
    # idc = serializers.SerializerMethodField()
    name = serializers.CharField(required=True)

    # def get_idc(self,obj):
    #     print(obj.idc)
    #     return {
    #         "idc": obj.id,
    #         "name": obj.name
    #     }
    def to_representation(self, instance):
        idc_obj = instance.idc
        ret = super(CabinetSerializer, self).to_representation(instance)
        ret["idc"] = {
            "idc": idc_obj.id,
            "name": idc_obj.name
        }
        return ret

    def  to_internal_value(self, data):
        print(data)
        return super(CabinetSerializer,self).to_internal_value(data)

    def create(self, validated_data):
        # raise serializers.ValidationError("create error")
        return Cabinet.objects.create(**validated_data)
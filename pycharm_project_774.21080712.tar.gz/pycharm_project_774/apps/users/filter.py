import django_filters
from django.contrib.auth import get_user_model
from django.contrib.auth.models import User
user = get_user_model()

class UserFilter(django_filters.FilterSet):
    username = django_filters.CharFilter(name="username",lookup_expr='contains')

    class Meta:
        model = User
        fields = ['username']
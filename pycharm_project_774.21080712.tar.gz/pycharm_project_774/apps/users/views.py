from django.shortcuts import render
from rest_framework import viewsets
# from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
from rest_framework.pagination import PageNumberPagination
User = get_user_model()

from .serializers import UserSerializer
from .pagination import Pagination
from .filter import UserFilter

from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.authentication import SessionAuthentication
from rest_framework.permissions import IsAuthenticated

class UserViewset(viewsets.ReadOnlyModelViewSet):
    """
    retrieve:
        返回指定用户信息
    list:
        返回用户列表
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer
    filter_class = UserFilter
    filter_fields = ("username",)
    # permission_classes = (IsAuthenticated,)
    extra_perm_map = {
        "GET": ['Users.view_user']
    }

    # pagination_class = Pagination

    # def get_queryset(self):
    #     queryset = super(UserViewset,self).get_queryset()
    #     username = self.request.query_params.get("username",None)

# class DashboardStatusViewset(viewsets.ViewSet,mixins.ListModelMixin)：

class DashboardStatusViewset(viewsets.ViewSet):
    pass
